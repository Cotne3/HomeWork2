
public class Main {
    static void main() {

    }
}
